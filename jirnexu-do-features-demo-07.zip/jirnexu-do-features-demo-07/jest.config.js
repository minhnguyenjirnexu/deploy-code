module.exports = {
    preset: 'jest-puppeteer',
    testRegex: './*\\.e2e\\.js$'
};