import React, { useEffect, useState } from 'react';
import * as Sentry from '@sentry/browser';
import './App.css';
import { useMachine } from '@xstate/react';
import Field from './components/Field';
import HistoryField from './components/HistoryField';
import { meta, fieldName } from './components/FormService';
import {Button} from './components/Button';
import { ocbFormMachine, OCBContext } from './forms/ocb';
import { logState } from './lib/Utils';
import convertStyle  from './lib/ConvertStyle';
import { State, Actor, AnyEventObject } from 'xstate';
import { Preloader } from './components/Preloading';

Sentry.init({dsn: "https://609ae253603a43fe90b8d3f1c87d021e@sentry.io/1801688"});
const serializedState = localStorage.getItem("stored-state");

// const OCB_FETCH_URL = 'http://localhost:3000';

let previousState: any;

if(serializedState) {
  previousState = JSON.parse(serializedState);
}

const Welcome: React.FC<any> = (props: any) => {
  const {current, service} = props;
  if (!current.matches("welcome")) return null

  return <Wrap>
    <div style={{textAlign: 'left', padding: '0 20px'}}>
      <img src={meta(current,service).logoUrl} alt={meta(current,service).brandName}/>
      <h3>{meta(current,service).usp}</h3>
      <ul>
        {meta(current,service).advantages.map((advantage: String, index: number) => (<li key={index}>{advantage}</li>))}
      </ul>
      <p>{meta(current,service).content}</p>
      <Button onClick={() => {
        service.send('LOGIN');
      }} name="Đăng ký ngay" current={current} service={service} />
    </div>
  </Wrap>
}

const Wrap: React.FC<any> = (props: any) => {

  const [style, setStyle] = useState({});
  
  useEffect(() => {
    const updateStyle = () => {
      const windowHeight = window.innerHeight;
      const convertedStyle = convertStyle(undefined, windowHeight);
      setStyle(convertedStyle);
    };

    updateStyle();

    window.addEventListener('resize', updateStyle);

    return () => {
      window.removeEventListener('resize', updateStyle);
    }
  }, []);

  return <div {...props} style={style}/>
}

const Complete: React.FC<any> = (props: any) => {
  const {current, service} = props;

  if (!current.matches("complete")) return null

  return <Wrap>
    <div>
      <h1>Ho So vay cua ban da duoc gui den COM-B</h1>
      <p>Yeu cau vay cua ban da duoc gui den doi tac cho vay. Ban se nhan duoc email tom tat trong vai phut.</p>
      <div>
        {current.context ? JSON.stringify(current.context.formValue) : ''}
      </div>
      <Button onClick={() => {
        localStorage.removeItem('stored-state');
        window.location.reload();
        service.send('LOGOUT');
      }} name="Log out" service={service}/>
    </div>
  </Wrap>
}

const Invalid: React.FC<any> = (props: any) => {
  const {current, service} = props;

  if (!current.matches("invalid")) return null

  return <Wrap>
    <div>
      <h1>Invalid!</h1>
      <Button onClick={() => {
        localStorage.removeItem('stored-state');
        window.location.reload();
        service.send('LOGOUT');
      }} name="Log out" service={service}/>
    </div>
  </Wrap>
}

const App: React.FC = () => {
  const machineState = useMachine(ocbFormMachine, {
    state: previousState,
    immediate: false
  });
  const service = machineState[2];
  const current = machineState[0];
  const send = machineState[1];

  const [child, setChild] = useState({});
  const initalChildService: Actor<any, AnyEventObject>[] = []; 
  const [childService, setChildService] = useState(initalChildService);

  useEffect(() => {
    service.onTransition((state: State<OCBContext, any>) => {
      try {
        logState(state);
        const type: string = state.event.type;
        const childrens = Object.values(state.children);
        if(childrens && childrens.length) {
          setChildService(childrens);
          childrens[0].subscribe((childState: State<OCBContext, any>) => {
            setChild(childState);
          })
        } else {
          setChildService([]);
        }
        if(state.changed) {
          if(["NEXT", "PREV"].indexOf(type) > -1) {
            if(type === "NEXT") {
              window.history.forward();
            } else {
              window.history.back();
            }
          } else {
            if(type !== 'POPSTATE') {
              const _fieldName = fieldName(state, service);
              if(_fieldName && _fieldName !== '') {
                window.history.pushState(null, "DO " + (fieldName(state, service) || ''), "/"+ (fieldName(state, service) || ''))
              }
            }
          }
        }
      } catch (e) {
        console.log(e);
      }
    });
  }, [service]);

  useEffect(() => {
    window.onpopstate = function(event: any) {
      const pathName = window.location.pathname;
      if(pathName !== '') {
        const dest = pathName.replace('/', '');
        send("POPSTATE", {dest});
      }
    }
  }, [send])
  
  return (
    <Preloader>
      <div className="App" style={{
        display: 'flex',
        flexDirection: 'column',
      }}>
        <header className="App-header" style={{flex: 1, alignItems: current.matches('field') ? 'flex-end' : 'center'}}>
          <div className="main">
            {
              current.context.stacks.length > 0 ? current.context.stacks.map((stack: any, index: number) => {
                if(typeof Object.values === 'undefined') {
                  Object.values = (obj: any) => Object.keys(obj).map(key => obj[key])
                }
                const history = (Object.values(stack) as any)[0].state;
                return <HistoryField service={service} current={current} history={history} key={index} index={index}></HistoryField>;
              }) : null
            }
            <Welcome service={service} current={current}></Welcome>
            {childService && childService.length ? <Field service={childService[0]} current={child} isChild={true}></Field> : <Field service={service} current={current}></Field>}
            <Complete service={service} current={current}></Complete>
            <Invalid service={service} current={current}></Invalid>
          </div>
        </header>
      </div>
    </Preloader>
  );
}

export default App;
