const rvhRegex = /(\d+(\.\d*)?)rvh(?!\w)/;
const defaultStyle = { height: '100rvh', display: 'flex', alignItems: 'center' };
// const containsRVH: Function = (propertyValue: any): boolean => {
//     return rvhRegex.test(propertyValue);
// }

const replaceRvhWithPx: Function = (propertyValue: String, windowHeight: number): String => {
    return propertyValue.replace(
        rvhRegex,
        (_, rvh) => `${windowHeight * parseFloat(rvh) / 100}px`
    )
}

const throwOnBadArgs: Function = (givenStyle: any, windowHeight: number): void => {
    if((typeof givenStyle !== 'object' && givenStyle !== undefined) || Array.isArray(givenStyle)) {
        throw Error(`style (the first argument) must be an object or undefined`);
    }

    if(typeof windowHeight !== 'number' || windowHeight < 0) {
        throw Error(`Second argument (windowHeight) must be a non negative number`);
    }
}

const convertStyle: Function = (givenStyle: any, windowHeight: number): any => {
    throwOnBadArgs(givenStyle, windowHeight);

    const usedStyle = givenStyle === undefined ? defaultStyle : givenStyle;

    let result: any = {};

    Object.keys(usedStyle).forEach((key) => {
        result[key] = typeof usedStyle[key] === 'string' ? replaceRvhWithPx(usedStyle[key], windowHeight) : usedStyle[key]
    });

    return result;
}

export default convertStyle;