import { StateValue } from "xstate";

export type FieldProps = {
    currentState: StateValue | undefined,
    onChange?: Function
}

export type SelectProps = {
    currentState: StateValue | undefined,
    onSelect?: Function
}


export type IChildRef = {
    [key: string]: any
}

export type HintType = {
  label: string,
  action: string
}