import { Machine } from "xstate";
import { respond } from "xstate/lib/actions";

export const UploadFileMachine = Machine({
    id: 'upload-file',
    initial: 'getFile',
    states: {
        getFile: {
            on: {
                FILES: {
                    actions: respond('UPLOAD_SUCCESS', {
                        delay: 1
                    })
                }
            }
        }
    }
})