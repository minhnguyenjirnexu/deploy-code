import { State, EventObject } from "xstate";
import { OCBContext } from "../forms/ocb";

export const logState = (state: State<OCBContext, EventObject>) => {
  if (console && console.groupCollapsed && console.log && console.groupEnd && process.env.REACT_APP_MODE !== 'test') {
    console.group(`[MachineTransition]: `);
    console.log(state.value, { ...state });
    console.groupEnd();
  }
};


export const EMI = (ir: number, np: number, pv: number, fv: number, type: number) => {
  if(ir !== 0) {
    const anualIr = Math.pow((1 + ir), np);
    return (pv * anualIr * ir) / (anualIr - 1);
  }
  return 0;
}

export const isRequestState: Function = (current: any): boolean => {
  if(current && current.actions && current.actions.length > 0) {
    const types = current.actions.findIndex((action: any) => action.type === "xstate.start");
    return types > -1;
  }
  return false;
}