const PHONE_NUMBER_REGEXS: any = {
  MY: /(\+?6?0)[0-9]-*[0-9-.\s]{6,9}/,
  SG: /[6|8|9]\d{7}|\+65[6|8|9]\d{7}|\+65\s[6|8|9]\d{7}/,
  VN: /^(\+?(84|0))(\d{9}|9\d{8})$/
}

const ID_REGEXS: any = {
  MY: /(([[1-9]{2})(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01]))-([0-9]{2})-([0-9]{4})/,
  SG: /^[STFG]\d{7}[A-Z]$/,
  VN: /(^(?:[1-9]|0[1-9]|1[0-9]|20|2[0-9]|30|3[0-8])[0-9]{7}$)|(^[0-9][0-9]?[0-9]{10}$)/,
}

const YEAR_MILLISECONDS = 31536000000;

export function validateEmail(email: string) {
    const re = /^(([^<>()\\.,;:\s@"]+(\.[^<>()\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email.toLowerCase());
}

export function validatePhoneNumber(phoneNumber: string, countryCode: string = 'VN'): boolean {
  const regEx = PHONE_NUMBER_REGEXS[countryCode];
  return regEx.test(phoneNumber.toLowerCase());
}

export function validateID(id: string, countryCode: string = 'VN') {
  const re = ID_REGEXS[countryCode];
  return re.test(id.toLowerCase());
}

export function checkExpireIdDay(date: string) {
  const issueDate = new Date(date).getTime();
  const toDate = new Date().getTime();
  return Number((toDate - issueDate) / YEAR_MILLISECONDS) < 15;
}