import { isRequestState } from "../lib/Utils";

export const fields = (formService?: any):string => {
  return (formService.value as any).field;
}
export const fieldName = (current?: any, formService?: any):string => meta(current,formService).name
export const meta = (current?: any, service?: any):any => {
  let ret:any = {}
  if(isRequestState(current)) {
    return ret;
  }
  if(current && typeof current != 'undefined' && service !== null) {
    for (let stateId of current.toStrings()) {
      const stateIds = stateId.split('.');
      const isChildCompare = service.parent ? 1 : 2;
      const isChild = stateIds.length > isChildCompare;
      if(isChild) {
        const machineId = service.machine.id;
        const meta = current.meta;
        ret = generateChild(ret, machineId, stateId, meta, stateIds);
      } else {
        Object.assign(ret, {
          ...current.meta[service.machine.id+"."+stateId],
          stateId
        })
      }
    }
  }
  return ret
}

const generateChild = (ret: any, machineId: string, stateId: string, meta: any, stateIds: string[], isHistory: boolean = false) => {
  const compareBool = isHistory ? 4 : 3;
  const keyStateId = isHistory ? stateId : (machineId + "." + stateId);
  if(stateIds.length > compareBool) {
    stateIds.pop();
    const parentStateId = stateIds.join('.');
    let childs:any = ret.child;
    if(childs && childs.length) {
      let index = childs.findIndex((child: any) => child.stateId === parentStateId);
      let found = childs[index];
      if(found) {
        if(Object.keys(found).indexOf('child') === -1) {
          found.child = [{
            ...meta[keyStateId],
            stateId
          }];
        } else {
          found.child = [...found.child, {
            ...meta[keyStateId],
            stateId
          }];
        }
      }
    }
  } else {
    if(Object.keys(ret).indexOf('child') === -1) {
      ret.child = [{
        ...meta[keyStateId],
        stateId
      }];
    } else {
      ret.child = [...ret.child, {
        ...meta[keyStateId],
        stateId
      }];
    }
  }
  

  return ret;
}

export const historyMeta = (history?: any, service?: any): any => {
  let ret: any = {};

  if(history && typeof history !== 'undefined') {
    const keys = Object.keys(history.meta).filter(key => key !== service.machine.id);
    for(let key of keys) {
      const stateIds = key.split('.');
      const isChild = stateIds.length > 3;
      if(isChild) {
        const machineId = service.machine.id;
        const meta = history.meta;
        ret = generateChild(ret, machineId, key, meta, stateIds, true);
      } else {
        Object.assign(ret, {
          ...history.meta[key],
          stateId: key
        })
      } 
    }
  }

  return ret;
}

export const buttonName = (current?: any, service?: any):string => meta(current, service).buttonName && meta(current, service).buttonName !== '' ? meta(current, service).buttonName : 'Continue'

export const fieldTitle = (current?: any, service?: any):string => meta(current, service).title
