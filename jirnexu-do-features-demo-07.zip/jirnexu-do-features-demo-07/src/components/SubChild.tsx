import React from "react";
import { IOptions } from "../forms/ocb";
import { Input } from "./Input";

export const SubChild: any = React.forwardRef((props: any, ref: any) => {
  const {elem, getCurrentStateName, currentFormValue} = props;
  
  if(elem.child && elem.child.length > 0) {
    if(elem.showWhen) {
      const condField = elem.showWhen['field'];
      const condValue = elem.showWhen['value'];
      if(!(currentFormValue && currentFormValue[condField] === condValue)) {
        return null;
      }
    }

    return <div>
    <p>{elem.title}</p>{
      elem.child.map((el: any, idx: number) => {
      return <div key={el.stateId}>
        <label htmlFor={el.stateId}>{el.title}</label>
        {
          (
            el.options ? <div>
              <select ref={ref ? ref[el.stateId] : React.createRef()} name={el.stateId}
                defaultValue={getCurrentStateName(currentFormValue, el.stateId)}
                onChange={el.onChange ? (event) => {
                    
                }: (event) => {}}
                id={el.stateId}
              >
                {el.options.map((opt:IOptions) => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
              </select>
            </div> : !(el.hasInput === false) ? <Input ref={ref ? ref[el.stateId] : React.createRef()} 
              defaultValue={getCurrentStateName(currentFormValue, el.stateId)}
              name={ el.stateId } type={el.type || "text"} placeholder={el.placeholder} meta={el}/> : null
          )
        }
      </div>
      })
    }
    </div>
  }
  return null;
});