import React, { useState } from "react";
import { InputProps } from "./Input";

export const FileField: any = React.forwardRef((props: InputProps, ref: any) => {
    const {meta} = props;
    const [selectedFile, setSelectedFile] = useState(props.defaultValue && props.defaultValue !== '' ? URL.revokeObjectURL(props.defaultValue) : '');
    return <div className="container">
      <div className="row">
        <div className="offset-md-3 col-md-6">
          <div className="form-group files">
            <label htmlFor={meta.stateId}>{meta.title}</label>
            <input type="file" className="form-control" ref={ref} onChange={(event: any) => {
              setSelectedFile(URL.createObjectURL(event.target.files[0]));
              props.service.send('UPDATE_FORM_VALUE', {field: meta.stateId, value: event.target.files[0]});
            }}/>
            {
              selectedFile && selectedFile !== '' ? <img src={selectedFile} style={{
                maxWidth: '100%'
              }} alt={meta.title}/> : null
            }
          </div>
        </div>
      </div>
    </div>;
  }
);