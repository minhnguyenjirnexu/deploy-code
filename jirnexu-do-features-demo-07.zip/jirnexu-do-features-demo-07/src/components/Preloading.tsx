import React from "react";

type PreloaderProps = {
	fadeDuration?: number,
	className?: string,
	children?: React.ReactNode,
	style?: any
};

type PreloaderState = {
	loaded: boolean
};

type PlaceholderProps = {
	children?: React.ReactNode
};

const defaultStyle = {
	opacity: 1,
	zIndex: 999,
	backgroundColor: 'white',
	height: '100vh',
	width: '100vw',
	position: 'fixed',
	top: 0,
	left: 0,
	display: 'flex',
	justifyContent: 'center',
	alignItems: 'center',
};

class Preloader extends React.Component<PreloaderProps, PreloaderState> {
	state = { loaded: false };

	ref: any;

	componentDidMount = () => {
		window.requestAnimationFrame(this.checkReadyState);
	};

	checkReadyState = () => {
		if (document.readyState === 'complete' && this.ref) {
			this.ref.style.opacity = '0';
			setTimeout(() => {
				this.setState({ loaded: true });
				this.ref = null;
			}, this.props.fadeDuration || 200);
		} else {
			window.requestAnimationFrame(this.checkReadyState);
		}
	};

	render() {
		const { style, className, children, fadeDuration } = this.props;

		const cleanChildren = React.Children.map(
			children,
			(child: any) =>
				(child.type.displayName === 'PreloadingPlaceholder' ? null : child)
		);

		return (
			<React.Fragment>
				{cleanChildren}
				{
					this.state.loaded
						? null
						: (
							<div
								style={{
									...defaultStyle,
									transition: `opacity ${fadeDuration || 200 / 1000}s ease`,
									...style,
								}}
								className={className}
								ref={(ref) => {
									this.ref = ref;
								}}
							>
								<div className="loadicon loader show">
                                    <svg className="load-present" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
                                        <path className="stroke-line" d="M10.2,54.4c1.1,9.5,5.5,17.9,11.8,24c-0.7-2-0.9-4.1-0.5-5.9 c1.4-5.7,7.1-9.5,15-10.7V34.7C15.6,31.1,8.8,44.2,10.2,54.4"></path>
                                        <path className="stroke-line" d="M89.9,45.6c-1.1-9.5-5.5-17.9-11.8-24c0.7,1.8,0.9,3.9,0.5,5.9 c-1.4,5.7-7.1,9.5-15,10.7v27.2C84.4,68.9,91,55.6,89.9,45.6"></path>
                                        <path className="stroke-line" d="M10.9,41c5.5-7.5,15.3-11.8,33.3-6.6C75.8,43.3,86,22.7,68,14.3 C62.5,11.6,56.4,10,50,10C30.9,10,15,23.4,10.9,41"></path>
                                        <path className="stroke-line" d="M89.2,58.7c-5.5,7.5-15.3,11.8-33.3,6.6c-31.9-8.8-42.1,11.8-24.1,20.4 c5.5,2.7,11.6,4.3,18,4.3C69.2,89.8,85.1,76.6,89.2,58.7"></path>
                                    </svg>
                                </div>
							</div>
						)}
			</React.Fragment>
		);
	}
}

const Placeholder = ({ children }: PlaceholderProps) => (
	<React.Fragment>{children}</React.Fragment>
);

Placeholder.displayName = 'PreloadingPlaceholder';

export { Preloader, Placeholder };