import React from "react";
import { meta, fieldTitle } from "./FormService";
import { FieldGroup } from "./FieldGroup";
import { Button } from "./Button";
import { isString } from "util";
import { IChildRef, HintType } from "../lib/Types";
import { isRequestState } from "../lib/Utils";
import { Spinner } from './Spinner';
import { ContinueButton } from "./ContinueButton";
import { UploadButton } from "./UploadButton";
  
export default class Field extends React.Component<any, {}, any> {
    childRefs: IChildRef;
    fieldSetEnd: any;
    isUploadFile: boolean;
    
    constructor(props: any) {
      super(props)
      this.childRefs = {};
      this.isUploadFile = false;
      this._setDefaultChildRefs();
    }

    scrollToBottom = () => {
      if(this.fieldSetEnd) {
        this.fieldSetEnd.scrollIntoView({ behavior: "smooth" });
      }
    }

    componentDidUpdate() {
      this.scrollToBottom();
    }
  
    componentWillUpdate() {
      this._setDefaultChildRefs();
    }

    _setDefaultChildRefs = () => {
      const { service } = this.props;
      const _meta = meta(service.state, service);
      
      this.childRefs = _meta.child && _meta.child.length ? _meta.child.reduce((previousValue: any, currentValue: any, index: number) => {
        const {stateId} = currentValue;
        
        if(currentValue.child && currentValue.child.length) {
          const {child} = currentValue;
          const childRefs = child.map((c: any) => {
            const childStateId = c.stateId;
            if(c && c.options) {
              return {
                childStateId,
                ref:React.createRef<HTMLSelectElement>()
              }
            } else {
              if(c.type && c.type === 'file') {
                this.isUploadFile = true;
              }
              return {
                childStateId,
                ref: React.createRef<HTMLInputElement>()
              }
            }
          }).reduce((prev: any, current: any) => {
            return {
              ...prev,
              [current['childStateId']]: current['ref'],
            };
          }, {})
          previousValue[stateId] = childRefs
          
        } else {
          if(currentValue && currentValue.options) {
            previousValue[stateId] = React.createRef<HTMLSelectElement>();
          } else {
            if(currentValue.type && currentValue.type === 'file') {
              this.isUploadFile = true;
            }
            previousValue[stateId] = React.createRef<HTMLInputElement>();
          }
        }

        
        return previousValue;
      }, {}) : {};
    }
    
    send(eventName: string, payload: {}) {
      this.props.service.send(eventName, payload)
    }

    formatHint() {
      const { service, current } = this.props;
      const _meta = meta(current, service);
      const hint: String | HintType[] = _meta.hint;
      if(!hint) return null;
      return isString(hint) ? hint : (hint as HintType[]).map((h: HintType, index: number) => {
        return h.action ? <button key={index} onClick={() => this.send(h.action, {})}>{h.label}</button> : <span key={index}>{h.label}</span>
      });
    }
  
    render() {
      const { service, current } = this.props;
      const _meta = meta(current, service);
      const _fieldTitle = fieldTitle(current, service);
      const _subTitle = _meta.subTitle;
      if ((!current.matches("field") || _meta.options) && !service.parent) return null
      if(isRequestState(current)) return <Spinner />;
      const currentIndex = current.context.currentIndex;
      const stacks = current.context.stacks;
      let machine = service.machine;
      if(service.parent) {
        machine = service.parent.machine;
      }
      return <fieldset name={_meta.name}>
        {_fieldTitle ? <legend style={{...machine.meta.title}}>{_fieldTitle}</legend> : null}
        <fieldset style={{
        }} className={currentIndex === stacks.length ? 'field__wrapper field__wrapper-current' : 'field__wrapper'}>
          {_subTitle ? <legend><label style={{...machine.meta.subTitle}} htmlFor={_meta.subTitle}>{_meta.subTitle}</label></legend> : null}
          <FieldGroup ref={this.childRefs} name={_meta.name} service={service} current={current}></FieldGroup>
          {this.formatHint() ? <><aside>{this.formatHint()}</aside></> : null}
        </fieldset>
        <p style={{
          display: 'flex',
          justifyContent: currentIndex > 0 ? 'space-between' : 'flex-end'
        }}>
          { currentIndex > 0 ? <Button onClick={() => {
            this.send("PREV", {});
          }} name={"PREV"} service={service} hideArrow={true} styles={{flex: 1}} /> : null }
          { currentIndex > 0 ? <div style={{width: '10px'}}></div>: null}
          
          {this.isUploadFile ? <UploadButton {...this.props} /> : <ContinueButton {...this.props} childRefs={this.childRefs} /> }
        </p>
        <div style={{ float:"left", clear: "both" }}
             ref={(el) => { this.fieldSetEnd = el; }}>
        </div>
      </fieldset>
    }
}