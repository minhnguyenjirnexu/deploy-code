import React, { useState } from "react";
import { meta, historyMeta } from "./FormService";
import { IOptions } from "../forms/ocb";
import { IChildRef } from "../lib/Types";
import { Input } from "./Input";
import { MonthlyField } from "./MonthlyField";
import {SubChild} from './SubChild';

const getCurrentStateName = (currentFormValue: any,stateId: String) => {
  if(!currentFormValue) return '';
  const states = stateId.split('.');
  let parentState = '';
  if(states.length > 4) {
    // Has parent state
    parentState = states[states.length - 2];
  }
  const state = states[states.length - 1];
  
  return parentState !== '' ?  currentFormValue[parentState][state] : currentFormValue[state];
}

export const FieldGroup: any = React.forwardRef((props: any, ref: IChildRef | null) => {
    const {current, service, isHistory} = props;
    if(current.actions && current.actions.length === 1 && current.actions[0].type === "xstate.start") {
      return null;
    }
    const _meta = isHistory ? historyMeta(current, service) : meta(current, service);
    const currentFormValue = current.context ? (current.context.formValue as any)[props['name']] : null;
    const [monthlyPay, setMonthlyPay] = useState(current.context.monthlyPay || 0);
    if(!(_meta.child && _meta.child.length)) return null;
    return _meta.child.map((elem: any, index: number) => elem ? 
      <p key={elem.stateId}><legend>{!(elem.child && elem.child.length) ? elem.title : ''}</legend>
      <SubChild {...props} meta={meta} elem={elem} getCurrentStateName={getCurrentStateName} currentFormValue={currentFormValue} ref={(ref as any)[elem.stateId]}/>
      
      {
        !elem.child ? (
          elem.options ? <label htmlFor={elem.stateId}>
            <select ref={ref ? ref[elem.stateId] : React.createRef()} name={ elem.stateId } 
              defaultValue={getCurrentStateName(currentFormValue, elem.stateId)}
              onChange={elem.onChange ? (event) => {
                props.service.send(elem.name, {value: event.currentTarget.value});
                const value = props.service.send(elem.onChange.name);
                setMonthlyPay((value.context as any)[elem.onChange.field]);
              }: (event) => {
                props.service.send('UPDATE_FORM_VALUE', {field: elem.stateId, value: event.currentTarget.value})
              }}
              id={elem.stateId}
            >
              {elem.options.map((opt:IOptions) => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
            </select>
          </label>
           : !(elem.hasInput === false) ? <Input ref={ref ? ref[elem.stateId] : React.createRef()} 
            defaultValue={getCurrentStateName(currentFormValue, elem.stateId)}
            name={elem.stateId} type={elem.type || "text"} placeholder={elem.placeholder} meta={elem} {...props} /> : elem.contextValue ? 
            <MonthlyField monthlyPay={monthlyPay}/>
            : null
        ) : null
      }
      
      { elem.child ? (<p>{elem.hint}</p>) : null }
      </p> : null);
  });