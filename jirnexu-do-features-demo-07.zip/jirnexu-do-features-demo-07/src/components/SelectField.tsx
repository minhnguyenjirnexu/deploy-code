import React from "react"
import { meta, fieldName, buttonName } from "./FormService"

export default class SelectField extends React.Component<any, {}, any> {
    inputRef: React.RefObject<HTMLSelectElement>
  
    constructor(props:any) {
      super(props)
      this.inputRef = React.createRef()
    }
  

    send(eventName: string, payload: {}) {
      this.props.service.send(eventName, payload)
    }
  
    render() {
      const {service, current} = this.props;
      const _meta = meta(current, service);
      if (!current.matches("field") || !_meta.options) return null
  
      const options = _meta.options.map((opt:string) => <option key={opt}>{opt}</option>)
      return <fieldset>
        <label htmlFor={fieldName(current, service)}>{_meta.question}</label>
        <select ref={this.inputRef} name={ fieldName(current, service) }>
          {options}
        </select>
        <aside>{_meta.hint}</aside>
        <button onClick={ () => this.send("CONTINUE", {value:(this.inputRef.current as any).value})}>{buttonName(current, service)}</button>
      </fieldset>
    }
  }