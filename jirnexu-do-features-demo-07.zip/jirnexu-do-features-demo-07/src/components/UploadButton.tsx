import React from 'react';
import {Button, ButtonProps} from './Button';
import { meta, buttonName } from "./FormService";
 
export const UploadButton: any = (props: ButtonProps) => {
    const { current, service } = props;
    const _meta = meta(current, service);
    const currentIndex = current.context.currentIndex;
    const stacks = current.context.stacks;

    return <Button {...props} onClick={async(event) => {
        event.preventDefault();
        let obj: any = {};
        obj[_meta.name] = {
            values: (current.context.formValue as any)[_meta.name], 
            state: current
        };
        service.send(currentIndex === stacks.length ? "CONTINUE" : "NEXT", {values: obj});
    }} name={currentIndex === stacks.length ? buttonName(current, service) : 'NEXT'} styles={currentIndex > 0 ? {flex: 1} : {width: '200px'}} />
}