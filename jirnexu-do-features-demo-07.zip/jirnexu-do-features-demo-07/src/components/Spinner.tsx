import React from "react";

export const Spinner: React.FC = () => {
    return <div style={{
        display: 'flex',
        alignItems: 'center'
    }}>
        <div id="spinner">
            <div className="spinner-child first" />
            <div className="spinner-child second" />
            <div className="spinner-child third" />
            <div className="spinner-child fourth" />
        </div>
    </div>
};