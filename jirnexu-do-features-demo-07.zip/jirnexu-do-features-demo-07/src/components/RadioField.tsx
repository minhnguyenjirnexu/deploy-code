import React, { useState } from "react";
import { InputProps } from "./Input";

export const RadioField: any = React.forwardRef((props: InputProps, ref: any) => {
    const {meta, defaultValue} = props;
    const {values} = meta;
    const [selected, setSelected] = useState(defaultValue || values[0].value);
    return <div className="container">
      <div className="row">
        {values.map((value: any, index: number) => (<div className="radio" key={index}>
          <label>
            <input type="radio" value={value.value} onChange={(event: any) => setSelected(value.value)} checked={value.value === selected} ref={ref}/>
            {value.label}
          </label>
        </div>))}
      </div>
    </div>;
  }
);