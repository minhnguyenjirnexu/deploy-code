import React, { MouseEventHandler } from 'react';

export type ButtonProps = {
    action?: string,
    name?: string,
    onClick?: MouseEventHandler<any>,
    service?: any,
    send?: any,
    current?: any,
    hideArrow?: boolean,
    styles?: any,
}

export type GlobalMeta = {
    primaryColor?: string,
    secondaryColor?: string,
    backgroundColor?: string,
    textColor?: string,
    disableColor?: string,
    button?: any,
}

export const Button: React.FC<ButtonProps> = (props: ButtonProps) => {
    const {service} = props;
    const style: GlobalMeta = service && service.parent ? service.parent.machine.meta : service.machine.meta;
    return  <div style={{position: 'relative', ...props.styles}}>
        <button onClick={props.onClick ? props.onClick : () => {
        props.action ? props.send(props.action) : console.log()
    }} style={style ? {
        backgroundColor: style.primaryColor,
        color: style.backgroundColor, 
        ...style.button,
    } : null}>
            {props.name || 'Send'}
        </button>
        {!props.hideArrow ? <span className="button-arrow slide-right"></span> : null }
    </div>
}