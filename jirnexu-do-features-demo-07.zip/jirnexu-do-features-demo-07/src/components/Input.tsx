import React, { useState } from 'react';
import { validateEmail, validatePhoneNumber } from './Validation';
import { FileField } from './FileField';
import { RadioField } from './RadioField';
import { AUTOCOMPLETE_VALID_INPUTS, AUTOCOMPLETE_VALID_VALUES } from '../lib/Autocompletes';

export type InputProps = {
    type?: string,
    defaultValue?: string,
    placeholder?: string,
    meta?: any,
    autocomplete?: any,
    name?: string,
    current?: any,
    service?: any
}

const ERROR_MESSAGES = {
    required: 'This field is required',
    email: 'Please enter a valid email address',
    phoneNumber: 'Please enter a valid phone number',
    minLength: 'Please enter at least {0} characters',
    maxlength: 'Please enter no more than {0} characters',
    accept: 'Please upload a valid file type: {0}'
}

export type Validate = {
    optional?: boolean,
    minLength?: number,
    maxLength?: number,
    accept?: string,
}

const validate: Function = (value: any, meta: any, inputType: string): any => {
    const type: Validate = meta.validate || {};
    if(!type.optional && value === '') {
        return {
            isValid: false,
            errorMessage: ERROR_MESSAGES.required
        };
    }

    if(inputType === 'email' && !validateEmail(value)) {
        return {
            isValid: false,
            errorMessage: ERROR_MESSAGES.email
        };
    }

    if(inputType === 'tel') {
        const countryCode = meta.countryCode || 'VN';
        if(!validatePhoneNumber(value, countryCode))
            return {
                isValid: false,
                errorMessage: ERROR_MESSAGES.phoneNumber
            };
    }

    if(type.minLength && typeof type.minLength !== 'undefined' && value.length < type.minLength) {
        return {
            isValid: false,
            errorMessage: ERROR_MESSAGES.minLength.replace('{0}', type.minLength.toString())
        }
    }

    if(type.maxLength && typeof type.maxLength !== 'undefined' && value.length > type.maxLength) {
        return {
            isValid: false,
            errorMessage: ERROR_MESSAGES.maxlength.replace('{0}', type.maxLength.toString())
        }
    }

    return {
        isValid: true,
        errorMessage: ''
    };
}

const getAutocomplete: Function = (inputType: string, value: string): string => {
    let autocomplete: string = "on";

    if(AUTOCOMPLETE_VALID_VALUES.indexOf(inputType) > -1) {
        autocomplete = inputType;
    }

    if(AUTOCOMPLETE_VALID_VALUES.indexOf(value) > -1) {
        autocomplete = value;
    }
    return autocomplete;
}

export const Input: any = React.forwardRef((props: InputProps, ref: any) => {
    const [error, setError] = useState('');
    const [value, setValue] = useState('');
    const type: string = props.type || 'text';
    if(type === 'file') return <FileField {...props} ref={ref}/>;
    if(type === 'radio') return <RadioField {...props} ref={ref} />;
    const validates: Validate = props.meta.validate || {};
    let inputProps: any = {};
    if(AUTOCOMPLETE_VALID_INPUTS.indexOf(type) > -1) {
        // When input type is exist on Array of valid inputs will work with autocomplete attributes
        inputProps.autoComplete = getAutocomplete(type, props.meta.autocomplete || '');
    }
    
    if(!validates.optional) inputProps.required = true;
    if(validates.minLength) inputProps.minLength = validates.minLength;
    if(validates.maxLength) inputProps.maxLength = validates.maxLength;
    if(props.placeholder && props.placeholder !== '') inputProps.placeholder = props.placeholder;
    if(props.name && props.name !== '') inputProps.name = props.name;
    return  <label htmlFor={props.name}>
        <input type={type} onChange={(event: any) => {
            setValue(event.target.value);
            const {isValid, errorMessage} = validate(event.target.value, props.meta, type);
            if(!isValid) {
                setError(errorMessage)
            } else {
                setError('');
            }
        }} ref={ref} defaultValue={props.defaultValue} style={{
            borderColor: value === '' ? 'initial' : (error !== '' ? 'red' : 'green')
        }} {...inputProps} id={props.name}/>
        <br/>
        <span>{error}</span>
    </label>;
});