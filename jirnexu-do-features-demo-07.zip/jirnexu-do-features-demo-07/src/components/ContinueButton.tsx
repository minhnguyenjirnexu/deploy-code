import React from 'react';
import { Button } from './Button';
import { meta, buttonName } from "./FormService";
 
export const ContinueButton: any = (props: any) => {
    const {current, service, childRefs } = props;
    const _meta = meta(current, service);
    const currentIndex = current.context.currentIndex;
    const stacks = current.context.stacks;

    return <Button {...props} onClick={async(event) => {
      event.preventDefault();
        const values: any[] = Object.keys(childRefs).reduce((prev: any, key: string) => {
            const keys = key.split('.');
            const childKeys = Object.keys(childRefs[key]);
            if(childKeys.length > 1) {
              const parentRef = childRefs[key];
              const cKeys = childKeys.reduce((p: any, current: string) => {
                const currentK = current.split('.');
                return {
                  ...p,
                  [currentK[currentK.length - 1]]: parentRef[current].current ? parentRef[current].current.value : ''
                }
              }, {});
              return {
                ...prev,
                [keys[keys.length - 1]]: cKeys
              }
            }
            return {
              ...prev,
              [keys[keys.length - 1]]: childRefs[key].current ? childRefs[key].current.value : ''
            }
          }, {});
          current && current.context ? (current.context.formValue as any)[_meta.name] = values : console.log('');
          let obj: any = {};
          obj[_meta.name] = {
            values, 
            state: current
          };
          service.send(currentIndex === stacks.length ? "CONTINUE" : "NEXT", {values: obj});
    }} name={currentIndex === stacks.length ? buttonName(current, service) : 'NEXT'} styles={currentIndex > 0 ? {flex: 1} : {width: '200px'}}/>
}