import React from "react";

type MonthlyType = {
    monthlyPay: number
}

export const MonthlyField: React.FC<MonthlyType> = (props: any) => {
    return <span style={{
        fontWeight: 700,
        fontSize: 20
    }}>{Math.round(props.monthlyPay).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')} VNĐ</span>;
  }