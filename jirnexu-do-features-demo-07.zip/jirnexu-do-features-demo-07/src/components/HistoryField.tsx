import React from "react";
import { historyMeta } from "./FormService";
import { FieldGroup } from "./FieldGroup";
import { isString } from "util";
import { IChildRef, HintType } from "../lib/Types";

export default class HistoryField extends React.Component<any, {}, any> {
  childRefs: IChildRef;
  
  constructor(props: any) {
    super(props)
    this.childRefs = {};
  }
  
  componentWillUpdate() {
    const { service, history } = this.props;
    const _meta = historyMeta(history, service);
    this.childRefs = _meta.child && _meta.child.length ? _meta.child.reduce((previousValue: any, currentValue: any, index: number) => {
      const {stateId} = currentValue;
        
      if(currentValue.child && currentValue.child.length) {
        const {child} = currentValue;
        const childRefs = child.map((c: any) => {
          const childStateId = c.stateId;
          if(c && c.options) {
            return {
              childStateId,
              ref:React.createRef<HTMLSelectElement>()
            }
          } else {
            return {
              childStateId,
              ref: React.createRef<HTMLInputElement>()
            }
          }
        }).reduce((prev: any, current: any) => {
          return {
            ...prev,
            [current['childStateId']]: current['ref'],
          };
        }, {})
        previousValue[stateId] = childRefs
        
      } else {
        if(currentValue && currentValue.options) {
          previousValue[stateId] = React.createRef<HTMLSelectElement>();
        } else {
          previousValue[stateId] = React.createRef<HTMLInputElement>();
        }
      }

      
      return previousValue;
    }, {}) : {};
  }
    
  send(eventName: string, payload: {}) {
    this.props.service.send(eventName, payload)
  }

  formatHint() {
    const { history, service } = this.props;
    const _meta = historyMeta(history, service);
    const hint: String | HintType[] = _meta.hint;
    if(!hint) return null;
    return isString(hint) ? hint : (hint as HintType[]).map((h: HintType, index: number) => {
      return h.action ? <button key={index} onClick={() => this.send(h.action, {})}>{h.label}</button> : <span key={index}>{h.label}</span>
    });
  }
  
  render() {
    const { service, current, history, index } = this.props;
    const hideHistories = ['welcome', 'complete', 'invalid'];
    if (!history || !current.matches("field") || hideHistories.indexOf(history.value) > -1) return null
    history.toStrings = current.toStrings;
    const currentIndex = current.context.currentIndex;
    const _meta = historyMeta(history, service);
    console.log(_meta);
    const _hint = this.formatHint();
    return <fieldset name={_meta.name}>
      <legend style={{...service.machine.meta.title}}>{_meta.title}</legend>
      <fieldset style={{
        backgroundColor: currentIndex === index ? 'yellow' : service.machine.meta.secondaryBackgroundColor, 
        margin: '10px 0',
        padding: '12px',
        borderRadius: '6px'
      }}>
        <legend style={{...service.machine.meta.subTitle}}>{_meta.subTitle}</legend>
        <FieldGroup ref={this.childRefs} name={_meta.name} service={service} current={history} isHistory={true}></FieldGroup>
        {_hint ? <p>{_hint}</p> : null }
      </fieldset>
    </fieldset>
  }
}