import { Machine } from 'xstate';
import { assign, send } from 'xstate/lib/actions';
import { validateEmail, validatePhoneNumber, validateID, checkExpireIdDay } from '../../components/Validation';
import { EMI } from '../../lib/Utils';
import { OTPMachine } from '../../machines/OtpMachine';
import { IDOCRMachine } from '../../machines/IDOCRMachine';
import { DLOCRMachine } from '../../machines/DLOCRMachine';
import { UploadMachine } from '../../machines/UploadMachine';

export interface IOptions {
  label: string,
  value: any
}

const genArr = (from: number, to: number, suffix: string) => {
  let results: IOptions[] = [];
  for (let i = from; i <= to; i++) {
    results.push({
      label: i + ' ' + suffix,
      value: i
    });  
  }

  return results;
}

export const OCB_CONSTANTS = {
  LONG_SCALE: 1000000,
  INSURANCE_RATE: 0.055,
  MIN_LOAN_AMOUNT: 10,
  MAX_LOAN_AMOUNT: 30,
  MIN_LOAN_TENOR: 12,
  MAX_LOAN_TENOR: 24,
  INTEREST_RATE: 0.42
}

export interface OCBContext {
  formValue: any,
  monthlyPay: number,
  loanAmount: number,
  loanDuration: number,
  currentIndex: number,
  stacks: [],
  otp: string,
  isAlreadyConfirmed: boolean
}

const parallel: 'atomic' | 'compound' | 'parallel' | 'final' | 'history' = "parallel";

const packageField = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'primaryInfo',
      cond: 'packageValid',
      actions: 'updateStacks'
    },
    NEXT: {
      actions: 'next'
    }
  },
  meta: {
    title: 'Chọn gói vay',
    name: 'package',
    buttonName: 'Continue',
    hint: 'Kết quả chỉ mang tính chất tham khảo và có thể khác với kết quả tinh toán thực tế'
  },
  states: {
    amount: {
      meta: {
        title: 'Khoản vay',
        name: 'UPDATE_AMOUNT',
        options: genArr(OCB_CONSTANTS.MIN_LOAN_AMOUNT, OCB_CONSTANTS.MAX_LOAN_AMOUNT, 'triệu'),
        onChange: {
          name: 'CHANGE',
          field: 'monthlyPay'
        }
      }
    },
    tenor: {
      meta: {
        title: 'Thời hạn vay',
        name: 'UPDATE_DURATION',
        options: genArr(OCB_CONSTANTS.MIN_LOAN_TENOR, OCB_CONSTANTS.MAX_LOAN_TENOR, 'tháng'),
        onChange: {
          name: 'CHANGE',
          field: 'monthlyPay'
        },
      }
    },
    monthlyPay: {
      meta: {
        title: 'Khoản trả hàng tháng',
        hasInput: false,
        readOnly: true,
        contextValue: 'monthlyPay'
      }
    }
  },
}

const primaryInfo = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'otp',
      cond: 'otpValid',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  meta: {
    title: 'Xác thực mã OTP',
    name: 'primaryInfo',
    buttonName: 'Gửi OTP',
    hint: 'Bằng việc cung cấp thông tin trên, bạn đồng ý với các điều khoản sử dụng của COM-B'
  },
  initial: 'name',
  states: {
    fullName: {
      meta: {
        title: 'Tên của bạn',
        placeholder: 'Họ và tên',
        validate: {
          minLength: 2
        },
        autocomplete: 'name'
      },
    },
    email: {
      meta: {
        title: 'Email',
        type: 'email',
        placeholder: 'Email...'
      }
    },
    phoneNumber: {
      meta: {
        title: 'Số di động',
        hint: 'Mã xác thực OTP sẽ được gửi đến số điện thoại này',
        type: 'tel',
        countryCode: 'VN'
      }
    },
    loanPurpose: {
      meta: {
        title: 'Mục đích vay',
        options: [{
          label: "Du lịch",
          value: 'travel'
        }, {
          label: "Ăn uống",
          value: 'food'
        }, {
          label: "Mua sắm",
          value: 'shopping'
        }]
      }
    }
  }
}

const profile = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'address',
      cond: 'isEmpty',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  meta: {
    subTitle: 'Vui lòng cung cấp thông tin cá nhân của bạn',
    buttonName: 'Continue',
    name: 'profile',
  },
  states: {
    educationLevel: {
      meta: {
        title: 'Trình độ học vấn',
        options: [{
          label: "Đại học",
          value: 'university'
        }, {
          label: "Cao đẳng",
          value: 'colleage'
        }]
      }
    },
    maritalStatus: {
      meta: {
        title: 'Tình trạng hôn nhân',
        options: [{
          label: "Kết hôn",
          value: 'married'
        }, {
          label: "Độc thân",
          value: 'single'
        }, {
          label:  "Goá",
          value: 'widow'
        }]
      }
    },
    noOfDependents: {
      meta: {
        title: 'Số người phụ thuộc'
      }
    }
  }
}

const address = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'additionInfo',
      cond: 'isEmpty',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  meta: {
    subTitle: 'Hãy điền địa chỉ nơi bạn đang sống',
    buttonName: 'Continue',
    name: 'address',
  },
  states: {
    city: {
      meta: {
        title: 'Tỉnh/Thành Phố',
        placeholder: 'TP. Hồ Chí Minh',
        autocomplete: 'address-level2'
      }
    },
    district: {
      meta: {
        title: 'Quận/ Huyện',
        placeholder: 'Quận 4',
        autocomplete: 'address-level3'
      }
    },
    ward: {
      meta: {
        title: 'Phường/Xã',
        placeholder: 'Phường 12'
      }
    },
    hamlet: {
      meta: {
        title: 'Hẻm',
        placeholder: '...'
      }
    },
    street: {
      meta: {
        title:' Tên Đường',
        placeholder: 'Đoàn Văn Bơ',
        autocomplete: 'street-address'
      }
    },
    unitNo: {
      meta: {
        title: 'Số nhà',
        placeholder: '12'
      }
    },
    isPermanentAddress: {
      meta: {
        type: 'radio',
        title: 'Đây cũng là địa chỉ thường trú ?',
        values: [
          {
            label: 'Đúng rồi',
            value: "yes"
          },
          {
            label: 'Không phải',
            value: "no"
          }
        ]
      }
    }
  }
}

const additionInfo = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'job',
      cond: 'isEmpty',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  initial: 'ownership',
  meta: {
    title: '',
    subTitle: 'Một vài thông tin bổ sung',
    name: 'additionInfo'
  },
  states: {
    ownership: {
      meta: {
        title: 'Hình thức sở hữu',
        options: [{
          label: 'Sở hữu',
          value: 'owner'
        }, {
          label: 'Cho thuê',
          value: 'rent'
        }]
      }
    },
    liveFrom: {
      meta: {
        title: 'Bạn sống ở đây từ',
        states: {
          month: {
            meta: {
              options: genArr(1, 12, '')
            }
          },
          year: {
            meta: {
              options: genArr(1900, 2020, ' nam')
            }
          }
        }
      }
    },
    homePhone: {
      meta: {
        title: 'Điện thoại bàn (nếu có)',
        placeholder: '090909090',
        type: 'tel'
      }
    }
  }
}

const job = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'workplace',
      cond: 'isEmpty',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  initial: 'state',
  meta: {
    title: '',
    name: 'job'
  },
  states: {
    state: {
      meta: {
        title: 'Tình trạng công viêc',
        options: [{
          label: "Làm hưởng lương",
          value: 'employee'
        }, {
          label: "Chủ doanh nghiệp",
          value: 'businessOwner'
        }, {
          label: "Kinh doanh hộ gia đình",
          value: 'householdBusinessOwner'
        }]
      }
    },
    employee: {
      type: parallel,
      meta: {
        title: 'Làm hưởng lương',
        showWhen: {
          field: 'state',
          value: 'employee'
        }
      },
      initial: 'businessType',
      states: {
        businessType: {
          meta: {
            title: 'Loại doanh nghiệp'
          }
        },
        companyName: {
          meta: {
            title: 'Tên công ty',
            autocomplete: 'organization'
          }
        },
        industry: {
          meta: {
            title: 'Ngành kinh doanh'
          }
        },
        companyPhoneNumber: {
          meta: {
            title: 'Số điện thoại công ty',
            type: 'tel'
          }
        },
        occupation: {
          meta: {
            title: 'Chức vụ'
          }
        },
        contractType: {
          meta: {
            title: 'Loại hợp đồng'
          }
        },
        workingExpCurrent: {
          meta: {
            title: 'Số năm làm việc tại công ty'
          }
        }
      },
    },
    businessOwner: {
      type: parallel,
      meta: {
        title: 'Chủ doanh nghiệp',
        showWhen: {
          field: 'state',
          value: 'businessOwner'
        }
      },
      initial: 'businessType',
      states: {
        businessType: {
          meta: {
            title: "Loại doanh nghiệp"
          }
        },
        businessName: {
          meta: {
            title: 'Tên doanh nghiệp',
            autocomplete: 'organization'
          }
        },
        industry: {
          meta: {
            title: 'Ngành nghề kinh doanh'
          }
        },
        companyPhoneNumber: {
          meta: {
            title: 'Số điện thoại công ty',
            type: 'tel'
          }
        },
        noOfYearsBusiness: {
          meta: {
            title: 'Số năm kinh doanh'
          }
        }
      },
    },
    householdBusinessOwner: {
      type: parallel,
      meta: {
        title: 'Kinh doanh hộ gia đình',
        showWhen: {
          field: 'state',
          value: 'householdBusinessOwner'
        }
      },
      initial: 'householdBusinessName',
      states: {
        householdBusinessName: {
          meta: {
            title: 'Tên doanh nghiệp',
            autocomplete: 'organization'
          }
        },
        industry: {
          meta: {
            title: 'Ngành nghề kinh doanh'
          }
        },
        companyPhoneNumber: {
          meta: {
            title: 'Số điện thoại doanh nghiệp',
            type: 'tel'
          }
        },
        noOfYearsBusiness: {
          meta: {
            title: 'Số năm kinh doanh'
          }
        }
      }
    }
  }
}

const workplace = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'income',
      cond: 'isEmpty',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  meta: {
    subTitle: 'Điạ chỉ nơi làm việc',
    name: 'workplace'
  },
  states: {
    isCurrent: {
      meta: {
        title: 'Giống điạ chỉ hiện tại',
        type: 'radio',
        values: [
          {
            label: 'Đúng rồi',
            value: "yes"
          },
          {
            label: 'Không phải',
            value: "no"
          }
        ]
      }
    },
    city: {
      meta: {
        title: 'Tỉnh/Thành Phố',
        placeholder: 'TP. Hồ Chí Minh',
        autocomplete: 'address-level2'
      }
    },
    district: {
      meta: {
        title: 'Quận/ Huyện',
        placeholder: 'Quận 4'
      }
    },
    ward: {
      meta: {
        title: 'Phường/Xã',
        placeholder: 'Phường 12'
      }
    },
    hamlet: {
      meta: {
        title: 'Hẻm',
        placeholder: 'Hẻm...'
      }
    },
    street: {
      meta: {
        title:' Tên Đường',
        placeholder: 'Đoàn Văn Bơ',
        autocomplete: 'street-address'
      }
    },
    unitNo: {
      meta: {
        title: 'Số nhà',
        placeholder: '12'
      }
    },
    isRegular: {
      meta: {
        type: 'radio',
        title: 'Đây cũng là địa chỉ thường trú ?',
        values: [
          {
            label: 'Đúng rồi',
            value: "yes"
          },
          {
            label: 'Không phải',
            value: "no"
          }
        ]
      }
    }
  }
}

const income = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'bankAccount',
      cond: 'isEmpty',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  meta: {
    subTitle: 'Nói thêm về tình hình tài chính của bạn',
    name: 'income'
  },
  states: {
    monthlyIncome: {
      meta: {
        title: 'Thu nhập bình quân hàng tháng'
      },
    },
    monthlyExpense: {
      meta: {
        title: 'Chi phí cá nhân'
      }
    },
    noOfCurrentLoan: {
      meta: {
        title: 'Khoản vay hiện có'
      }
    },
    noOfCreditCard: {
      meta: {
        title: 'Số lượng thẻ tín dụng',
        type: 'number'
      }
    }
  }
}

const bankAccount = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'references',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  meta: {
    subTitle: 'Để nhận tiền nhanh nhất, vuio lòng cung cấp chính xác thông tin tài khoản của bạn.',
    name: 'bankAccount'
  },
  initial: 'accountHolder',
  states: {
    accountHolder: {
      meta: {
        title: 'Chủ tài khoản'
      }
    },
    accountNumber: {
      meta: {
        title: 'Số tài khoản'
      }
    },
    bankName: {
      meta: {
        title: 'Ngân hàng'
      }
    },
    branch: {
      meta: {
        title: 'Chi nhánh'
      }
    },
    city: {
      meta: {
        title: 'Thành phố',
        autocomplete: 'address-level2'
      }
    }
  }
}

const references = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'idCard',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  initial: 'first',
  meta: {
    title: '',
    name: 'references'
  },
  states: {
    first: {
      type: parallel,
      meta: {
        title: 'Thông tin người tham chiếu thứ nhất',
      },
      initial: 'title',
      states: {
        title: {
          meta: {
            title: 'Danh xưng',
            autocomplete: 'honorific-prefix'
          }
        },
        fullName: {
          meta: {
            title: 'Họ tên',
            autocomplete: 'name'
          }
        },
        phoneNumber: {
          meta: {
            title: 'Số điện thoại',
            type: 'tel'
          }
        },
        relationship: {
          meta: {
            title: 'Mối quan hệ'
          }
        }
      }
    },
    second: {
      type: parallel,
      meta: {
        title: 'Thông tin người tham chiếu thứ hai'
      },
      initial: 'title',
      states: {
        title: {
          meta: {
            title: 'Danh xưng',
            autocomplete: 'honorific-prefix'
          }
        },
        fullName: {
          meta: {
            title: 'Họ tên',
            autocomplete: 'name'
          }
        },
        phoneNumber: {
          meta: {
            title: 'Số điện thoại',
            type: 'tel'
          }
        },
        relationship: {
          meta: {
            title: 'Mối quan hệ'
          }
        }
      }
    }
  }
}

const idCard = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'idCardOCR',
      cond: 'isEmpty',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  meta: {
    title: '',
    name: 'idCard'
  },
  states: {
    front: {
      meta: {
        title: 'Mặt trước CMND',
        type: 'file'
      }
    },
    back: {
      meta: {
        title: 'Mặt sau CMND',
        type: 'file'
      }
    }
  }
}

const idCardOCR = {
  invoke: {
    id: 'id-ocr',
    src: IDOCRMachine,
    data: (context: OCBContext) => context,
    onDone: 'idCardConfirm'
  },
  on: {
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  }
}

const idCardConfirm = {
  type: parallel,
  on: {
    CONTINUE: {
      cond: 'idValid',
      target: 'driverLicense',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  meta: {
    notice: 'Xin kiểm tra và xác nhận thông tin cá nhân được trích xuất từ CMND và vui lòng cập nhật nếu có sai lệch.',
    name: 'idCardConfirm'
  },
  states: {
    name: {
      meta: {
        title: 'Họ và tên',
        placeholder: 'Nguyen Van A',
        autocomplete: 'name'
      }
    },
    id: {
      meta: {
        title: 'Số CMND',
        placeholder: '2012019910'
      }
    },
    birthDate: {
      meta: {
        title: 'Ngày sinh',
        placeholder: '01/12/1980',
        type: 'date',
        autocomplete: 'bday'
      }
    },
    birthPlace: {
      meta: {
        title: 'Nơi sinh',
        placeholder: 'Ho Chi Minh',
        autocomplete: 'address-level2'
      }
    },
    issueDate: {
      meta: {
        title: 'Ngày cấp',
        placeholder: '20/11/2020',
        type: 'date'
      }
    }
  }
}

const driverLicense = {
  type: parallel,
  on: {
    CONTINUE: {
      target: 'driverLicenseOCR',
      actions: 'updateStacks'
    },
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  },
  meta: {
    title: '',
    name: 'driverLicense'
  },
  states: {
    front: {
      meta: {
        title: 'Mặt trước bằng lái xe',
        type: 'file'
      }
    },
    back: {
      meta: {
        title: 'Mặt sau bằng lái xe',
        type: 'file'
      }
    }
  }
}

const driverLicenseOCR = {
  invoke: {
    id: 'dl-ocr',
    src: DLOCRMachine,
    data: (context: OCBContext) => context,
    onDone: 'selfie'
  },
  on: {
    PREV: {
      actions: 'back'
    },
    NEXT: {
      actions: 'next'
    }
  }
}

const ocbFields = {
  id: 'ocb_field',
  initial: 'package',
  on: {
    POPSTATE: {
      actions: 'updateActive'
    },
    UPDATE_AMOUNT: {
      actions: assign<OCBContext>({
        loanAmount: (context: OCBContext, {value}: any) => {
          return parseInt(value);
        }
      })
    },
    UPDATE_DURATION: {
      actions: assign<OCBContext>({
        loanDuration: (context: OCBContext, {value}: any) => {
          return parseInt(value);
        }
      })
    },
    CHANGE: {
      actions: assign<OCBContext>({
        monthlyPay: (context: OCBContext, event: any) => {
          return calculateMonthlyRepayment(context.loanAmount, context.loanDuration)
        }
      })
    },
    UPDATE_FORM_VALUE: {
      actions: 'updateFormValue'
    }
  },
  states: {
    package: packageField, // Select amount, duration of LOAN
    primaryInfo: primaryInfo,
    otp: {
      invoke: {
        id: 'otp-machine',
        src: OTPMachine,
        data: (context: OCBContext) => context,
        onDone: 'profile'
      },
      entry: send<OCBContext, any>('CODE', {to: 'otp-machine'}),
      on: {
        PREV: {
          actions: 'back'
        },
        NEXT: {
          actions: 'next'
        }
      }
    }, // Input require information
    profile: profile, // Input some infor about education and marial status
    address: address, // Input some current address
    additionInfo: additionInfo, // Input additional infor
    job: job, // Input job information: job status, company information
    workplace: workplace, // Input workplace information: city, ward, district, street, number...
    income: income, // Input income information: monthly, current LOAN, debit card, dependents.
    bankAccount: bankAccount, // Input some bank account information
    references: references, // Input some infor about references.
    idCard: idCard, // Issue Card information
    idCardOCR: idCardOCR,
    idCardConfirm: idCardConfirm, // Confirm information generate after getting from API
    driverLicense: driverLicense, // Driver license information
    driverLicenseOCR: driverLicenseOCR,
    selfie: { // Take a picture with face to confirmation
      type: parallel,
      on: {
        CONTINUE: {
          target: 'uploadSelfie',
          actions: 'updateStacks'
        },
        PREV: {
          actions: 'back'
        }
      },
      meta: {
        title: '',
        name: 'selfie'
      },
      states: {
        image: {
          meta: {
            title: 'Selfie',
            type: 'file'
          }
        }
      }
    },
    uploadSelfie: {
      invoke: {
        id: 'selfie-machine',
        src: UploadMachine,
        data: (context: OCBContext) => context,
        onDone: '#ocb.complete'
      }
    }
  }
}

const titleStyle = {
  fontSize: '20px',
  color: '#000000',
  letterSpacing: 0,
  textShadow: '1px 1px 1px rgba(191,191,191,0.67)',
}

export const ocbOptions = {
  guards: {
    // Using with cond
    packageValid: (context:OCBContext, event: any) => {
      if(event.values.package.values.length === 0) {
        // Check the loan amount and loan duration is selected or not
        return false;
      } else {
        const {loanAmount, loanDuration} = event.values.package.values;
        return !(loanAmount === '' || loanDuration === '');
      }
    },
    otpValid: (context: OCBContext, event: any) => {
      const {values} = event;
      if(values.primaryInfo.values.length === 0) {
        return false;
      }
      const {name, email, phoneNumber, purpose} = values.primaryInfo.values;
      if(name === '' || email === '' || phoneNumber === '' || purpose === '') {
        return false;
      }

      if(!validateEmail(email)) {
        return false;
      }

      if(!validatePhoneNumber(phoneNumber)) {
        return false;
      }

      return true;
    },
    idValid: (context: OCBContext, event: any) => {
      const {values} = event;
      if(values.idCardConfirm.values.length === 0) {
        return false;
      }

      const {name, id, birthDate, birthPlace, issueDate} = values.idCardConfirm.values;

      if(name === '' || id === '' || birthDate === '' || birthPlace === '' || issueDate === '') {
        return false;
      }

      if(!validateID(id)) {
        return false;
      }

      if(!checkExpireIdDay(issueDate)) {
        return false;
      }

      return true;
    },
    isEmpty: (context: OCBContext, event: any) => {
      const {values} = event;
      const vals = (Object.values(values) as any)[0].values;
      return !(vals.length === 0 || (vals.length > 0 && vals.indexOf("") > -1));
    }
  },
  actions: {
    // Action implementation , using assign for action
    updateStacks: assign<any, any>({
      stacks: (context: any, { values }: any) => {
        return [].concat(context.stacks, values);
      },
      currentIndex: (context: any, { values }: any) => {
        return context.currentIndex + 1;
      },
    }),
    back: assign<any, any>({
      currentIndex: (context: any, { values }: any) => {
        return context.currentIndex - 1;
      },
    }),
    next: assign<any, any>({
      currentIndex: (context: any, { values }: any) => {
        return context.currentIndex + 1;
      },
    }),
    updateActive: assign<any, any>({
      currentIndex: (context: any, { dest }: any) => {
        const vals = context.stacks.map((stack: any) => Object.keys(stack)[0]);
        return vals.indexOf(dest) > -1 ? vals.indexOf(dest) : vals.length;
      },
    }),
    updateFormValue: assign<any, any>({
      formValue: ({formValue}: any, {field, value}: any) => {
        const stateIds = field.split('.');
        const states = stateIds.length;
        const currentState = stateIds[states - 1];
        const parentState = stateIds[states - 2];
        formValue[parentState] = {
          ...formValue[parentState],
          [currentState]: value
        };
        return formValue;
      }
    })
  },
  activities: {
    // Activities : Using with activity names of their implementation
  },
  services: {
    // Services: Using with src
  }
};

const calculateMonthlyRepayment = (amount: number = OCB_CONSTANTS.MIN_LOAN_AMOUNT, tenure: number = OCB_CONSTANTS.MIN_LOAN_TENOR) => {
  const {LONG_SCALE, INSURANCE_RATE, INTEREST_RATE} = OCB_CONSTANTS;
  const applyAmount = amount * LONG_SCALE;
  const insuranceCharge = applyAmount * INSURANCE_RATE;
  const totalLoanAmount = applyAmount + insuranceCharge;
  const ir = INTEREST_RATE/12;
  return EMI(ir, tenure, totalLoanAmount, 0, 0);
}

// This machine is completely decoupled from React
export const ocbFormMachine = Machine<OCBContext>({
  id: 'ocb',
  initial: 'welcome',
  context: {
    formValue: {},
    monthlyPay: calculateMonthlyRepayment(),
    currentIndex: 0,
    stacks: [],
    loanAmount: OCB_CONSTANTS.MIN_LOAN_AMOUNT,
    loanDuration: OCB_CONSTANTS.MIN_LOAN_TENOR,
    otp: '',
    isAlreadyConfirmed: false
  },
  meta: {
    primaryColor: '#008C44',
    secondaryColor: '#063342',
    backgroundColor: '#f1f1f1',
    secondaryBackgroundColor: '#FFFFFF',
    textColor: '#FFFFFF',
    disableColor: '#DFDEDE',
    button: {
      fontSize: '18px',
      borderRadius: '10px',
      width: '100%',
      margin: '0',
      border: 'none',
      fontWeight: 'bold'
    },
    title: titleStyle,
    subTitle: {
      ...titleStyle,
      fontSize: '13px',
      textShadow: 'none'
    }
  },
  states: {
    welcome: {
      on: { LOGIN: 'field' },
      meta: {
        name: 'welcome',
        brandName: 'COM-B',
        usp: "Vay tiêu dùng, vay ngay COM-B",
        advantages: ["Không cần thế chấp tài sản", "Thủ tục đơn giản, giải ngân tốc độ trong vòng 48h làm việc", "Thời gian linh động từ 3 - 36 tháng", "Lãi suất cạnh tranh", "Phù hợp với đa dạng đối tượng khách hàng từ 20 - 65 tuổi"],
        content: 'COM-B tin tưởng rằng sẽ mang đến cho Khách hàng những sản phẩm tài chính tiêu dùng tối ưu nhất. Tất cả các khách hàng có nhu cầu vay tiêu dùng khi đến với COM-B sẽ được hỗ trợ tận tình thông qua đội ngũ bán hàng chuyện nghiệp rộng khắp cả nước.',
        logoUrl: 'https://com-b.vn/Cms_Data/Sites/ComB/Themes/comb/images/logo.png',
        backgroundImage: 'https://b.f9.group.zp.zdn.vn/3927480028018378368/f1a16a0b1eaae7f4bebb.jpg'
      }
    },

    field: ocbFields,

    complete: {
      on: { LOGOUT: 'welcome' }
    },
    invalid: {
      on: {
        LOGOUT: 'welcome'
      }
    }
  },
}, ocbOptions);