import {ocbFormMachine, OCB_CONSTANTS, OCBContext} from '.';
import { interpret, Interpreter, Actor, AnyEventObject } from 'xstate';
import { assert } from 'chai';
import { EMI } from '../../lib/Utils';
const CONFIRM_EVENT: AnyEventObject = 'CONFIRM';
const SUCCESS_EVENT: AnyEventObject = 'SUCCESS';
describe('OCB machine', () => {
  it('should go to welcome screen when initial', done => {
    const formService = interpret(ocbFormMachine).start();

    assert.equal(formService.initialState.value, 'welcome');
    done();
  })

  it('should go to screen package when send "LOGIN" ', done => {
    const formService = interpret(ocbFormMachine).start();
    const response = formService.send('LOGIN');
    assert.hasAllKeys(response.value,['field'], 'Current state should be field for now');
    assert.hasAllKeys((response.value as any).field,['package'], 'Should initial to package stage');
    assert.hasAllKeys((response.value as any).field.package,['amount', 'tenor', 'monthlyPay'], 'Sub current states should contains: amount, duration and monthlyPay');
    done();
  })

  it('should calculate EMI when changing the Loan Amount and Loan Duration', done => {
    const formService = interpret(ocbFormMachine).start();
    formService.send('LOGIN'); // Go to field stage
    assert.equal(formService.state.context.loanAmount, OCB_CONSTANTS.MIN_LOAN_AMOUNT, 'Must equal to default Loan Amount: ' + OCB_CONSTANTS.MIN_LOAN_AMOUNT);
    assert.equal(formService.state.context.loanDuration, OCB_CONSTANTS.MIN_LOAN_TENOR, 'Must equal to default Loan Duration: ' + OCB_CONSTANTS.MIN_LOAN_TENOR);

    // Send action: UPDATE_AMOUNT to update loan amount
    formService.send("UPDATE_AMOUNT", {value: 17});
    assert.equal(formService.state.context.loanAmount, 17, 'Must update Loan Amount: 17');
    
    // Send action: UPDATE_DURATION to update loan amount
    formService.send("UPDATE_DURATION", {value: 14});
    assert.equal(formService.state.context.loanDuration, 14, 'Must update Loan Amount: 14');

    const tenor = formService.state.context.loanDuration;
    const applyAmount = formService.state.context.loanAmount * OCB_CONSTANTS.LONG_SCALE;
    const insuranceCharge = applyAmount * OCB_CONSTANTS.INSURANCE_RATE;
    const totalLoanAmount = applyAmount + insuranceCharge;
    const interestRate = OCB_CONSTANTS.INTEREST_RATE;
    const ir = interestRate/12;
    const expectEMI = EMI(ir, tenor, totalLoanAmount, 0, 0);

    formService.send("CHANGE");
    assert.equal(formService.state.context.monthlyPay, expectEMI, 'The monthly pay should equal to ' + expectEMI);
    done();
  })

  it('should not go to confirm otp screen when user not select the Loan duration and amount', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: []}}}); // Current page must stay in package page because of Guard false
    assert.hasAllKeys((formService.state.value as any).field, ['package'], 'Current page must be stay on package screen');
    done();
  })

  it('should go to Primary information screen when user select the Loan duration and amount', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}});
    assert.hasAllKeys((formService.state.value as any).field, ['primaryInfo'], 'Current page must be Primary Information page');
    done();
  })

  it('Context.currentIndex should initial when send "CONTINUE"', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}});
    assert.equal(formService.state.context.currentIndex, 1, 'Current Index must be intial and equal to 1');
    done();
  })

  /* OTP Screen */

  it('should not go to confirm otp screen when user not input anything in input fields', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}});  // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: []}}}); // Current page must stay in otp page because of Guard false
    assert.hasAllKeys((formService.state.value as any).field, ['primaryInfo'], 'Current page must be Primary Information page');
    done();
  })

  it('should not go to confirm otp screen when user input an invalid email', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email",phoneNumber: "0963214937", loanPurpose: 'travel'}}}});// Current page must stay in otp page because of Guard false
    assert.hasAllKeys((formService.state.value as any).field, ['primaryInfo'], 'Current page must be primaryInfo page');
    done();
  })

  it('should not go to confirm otp screen when user input an invalid phone number', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email",phoneNumber: "invalid phone", loanPurpose: 'travel'}}}});// Current page must stay in otp page because of Guard false
    assert.hasAllKeys((formService.state.value as any).field, ['primaryInfo'], 'Current page must be primaryInfo page');
    done();
  })

  it('should go to confirm otp screen when send "CONTINUE" on primaryInfo page', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    assert.equal(formService.state.children['otp-machine'].state.value, 'asking', 'Current page must be otp confirm page');
    done();
  })

  it('should go to resend otp screen when send "RESEND" on otp confirm page', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}});// Current page must be OTP confirm Page
    const childFormService = formService.state.children['otp-machine'];
    setTimeout(() => {
      const resending: any = 'RESEND';
      childFormService.send(resending);
      assert.equal(childFormService.state.value['otpConfirm'], 'otp' , 'Current page must be otp confirm otp page');
      done();
    }, 100);
  })

  it('Context.currentIndex must equal to 1 when send "PREV"', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}});// Current page must be OTP confirm Page
    assert.equal(formService.state.context.currentIndex, 2, 'Current Index must be intial and equal to 2');
    formService.send("PREV");
    assert.equal(formService.state.context.currentIndex, 1, 'Current Index must be intial and equal to 1');
    done();
  })

  /* End OTP Screen */

  /* OTP Confirm Screen */
  it.skip('should go to OTP request screen to validate data when send "CONTINUE" on otp confirm page', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    const childFormService = formService.state.children['otp-machine'];
    setTimeout(() => {
      const cont: any = 'CONTINUE';
      childFormService.send(cont, {values: {otpConfirm: {state: {}, values: {otp: ''}}}});
      assert.equal(formService.state.children['otp-machine'].state.value, 'confirming', 'Current page must be otp confirming page');
      done();
    }, 100);
  })

  it.skip('should stay in OTP confirm page when user not input in confirm code', done => {
    const formService: Interpreter<OCBContext, any, AnyEventObject> = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    formService.send("CONTINUE", {values: {otpConfirm: {state: {}, values: []}}});
    const childFormService: Actor<any, AnyEventObject> = formService.state.children['otp-machine'];
    setTimeout(() => {
      const cont: any = 'CONTINUE';
      const invalidValues: any = {values: {otpConfirm: {state: {}, values: []}}};
      childFormService.send(cont, invalidValues);
      assert.hasAllKeys(formService.state.children['otp-machine'].state.value, ["callOTP"], 'Current page must be otp confirming page');
      done();
    }, 100);
  })

  it.skip('Context.currentIndex must equal to 2 when send "PREV" and equal to 3 when send "CONTINUE" and equal to 1 when send "BACK" twice', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}});// Current page must be OTP confirm Page
    formService.send("CONTINUE", {values: {otpConfirm: {state: {}, values: ["123456"]}}});
    setTimeout(function () {
      assert.equal(formService.state.context.currentIndex, 3, 'Current Index must be intial and equal to 3');
      formService.send("PREV");
      assert.equal(formService.state.context.currentIndex, 2, 'Current Index must be intial and equal to 2');
      formService.send("PREV");
      assert.equal(formService.state.context.currentIndex, 1, 'Current Index must be intial and equal to 1');
      done();
    }, 3000);
  })

  /* End OTP Confirm Screen */

  /* OTP request screen */
  it.skip('shoud wait 3 seconds before transition to new state when go to OTP request page', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    formService.send("CONTINUE", {values: {otpConfirm: {state: {}, values: ["123456"]}}});
    setTimeout(function () {
      if(typeof formService.state.value === 'object') {
        assert.hasAllKeys((formService.state.value as any).field, ['profile'], 'Current page must be profile page');
      } else {
        assert.equal(formService.state.value, 'invalid', 'Current page must be invalid page');
      }
      done();
    }, 3000);
    
  })

  /* End OTP request screen */

  /* OTP resend screen */
  it.skip('should back to otp confirm screen when go to resend screen', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be OTP confirm Page
    formService.send("RESEND");
    setTimeout(function () {
      assert.hasAllKeys((formService.state.value as any).field, ['profile'], 'Current page must be OTP profile page');
      done();
    }, 2000);
  })

  /* End OTP resend screen */

  /* Profile Screen */
  it('Should go to Profile page when send "CONTINUE" in OTP confirm page in test mode ', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    const childFormService: Actor<any, AnyEventObject> = formService.state.children['otp-machine'];
    
    setTimeout(function () {
      childFormService.send(CONFIRM_EVENT);
      childFormService.send('CONTINUE', {values: {otpConfirm: {state: {}, values: {otp: '1234'}}}});
      setTimeout(function() {
        childFormService.send('SUCCESS');
        assert.hasAllKeys((formService.state.value as any).field, ['profile'], 'Current page must be profile page');
        done();
      }, 10);
    }, 100);
  })

  it('Should not go to address if not select the marial status and education level', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    const childFormService: Actor<any, AnyEventObject> = formService.state.children['otp-machine'];
    setTimeout(function () {
      childFormService.send(CONFIRM_EVENT);
      childFormService.send('CONTINUE', {values: {otpConfirm: {state: {}, values: {otp: '1234'}}}});
      setTimeout(function() {
        childFormService.send('SUCCESS');
        assert.hasAllKeys((formService.state.value as any).field, ['profile'], 'Current page must be profile page');
        formService.send("CONTINUE", {values: {profile: {state: {}, values: []}}});

        assert.hasAllKeys((formService.state.value as any).field, ['profile'], 'Should stay in current page because user not select any options');
        done();
      }, 10);
    }, 100);
  })

  it('Should go to Address Screen if user select Education Level and Marial Status', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    const childFormService: Actor<any, AnyEventObject> = formService.state.children['otp-machine'];
    setTimeout(function () {
      childFormService.send(CONFIRM_EVENT);
      childFormService.send('CONTINUE', {values: {otpConfirm: {state: {}, values: {otp: '1234'}}}});
      setTimeout(function() {
        childFormService.send('SUCCESS');
      assert.hasAllKeys((formService.state.value as any).field, ['profile'], 'Current page must be profile page');
      formService.send("CONTINUE", {values: {profile: {state: {}, values: ["Đại học", "Kết hôn"]}}});

      assert.hasAllKeys((formService.state.value as any).field, ['address'], 'Current page must be address page');
      done();
      }, 10);
    }, 100);
  })

  /* End Profile Page */
  
  /* AdditionInfo Screen */
  it('Should not go to AdditionInfo Screen if user not input anything in City, District, Ward, Street and No.', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    const childFormService: Actor<any, AnyEventObject> = formService.state.children['otp-machine'];
    setTimeout(function () {
      childFormService.send(CONFIRM_EVENT);
      childFormService.send('CONTINUE', {values: {otpConfirm: {state: {}, values: {otp: '1234'}}}});
      setTimeout(function() {
        childFormService.send('SUCCESS');
      formService.send("CONTINUE", {values: {profile: {state: {}, values: ["Đại học", "Kết hôn"]}}});
      formService.send("CONTINUE", {values: {address: {state: {}, values: []}}});
      assert.hasAllKeys((formService.state.value as any).field, ['address'], 'Current page must be address page');
      done();
      }, 10);
    }, 100);
  })

  it('Should go to AdditionInfo Screen if user enter full information', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    const childFormService: Actor<any, AnyEventObject> = formService.state.children['otp-machine'];
    setTimeout(function () {
      childFormService.send(CONFIRM_EVENT);
      childFormService.send('CONTINUE', {values: {otpConfirm: {state: {}, values: {otp: '1234'}}}});
      setTimeout(function() {
        childFormService.send('SUCCESS');
        formService.send("CONTINUE", {values: {profile: {state: {}, values: ["Đại học", "Kết hôn"]}}});
        formService.send("CONTINUE", {values: {address: {state: {}, values: ["Ho Chi Minh", "4", "12", "Doan Van Bo", "12"]}}});
        assert.hasAllKeys((formService.state.value as any).field, ['additionInfo'], 'Current page must be AdditionInfo page');
        done();
      }, 10);
    }, 100);
  })

  /* End AdditionInfo Screen */


  /* Job Screen */
  it('Should not go to Job Screen if user not input anything in liveFrom, and not select from ownership', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    const childFormService: Actor<any, AnyEventObject> = formService.state.children['otp-machine'];
    setTimeout(function () {
      childFormService.send(CONFIRM_EVENT);
      childFormService.send('CONTINUE', {values: {otpConfirm: {state: {}, values: {otp: '1234'}}}});
      setTimeout(function() {
        childFormService.send('SUCCESS');
        formService.send("CONTINUE", {values: {profile: {state: {}, values: ["Đại học", "Kết hôn"]}}});
        formService.send("CONTINUE", {values: {address: {state: {}, values: ["Ho Chi Minh", "4", "12", "Doan Van Bo", "12"]}}});
        formService.send("CONTINUE", {values: {additionInfo: {state: {}, values: []}}});
        assert.hasAllKeys((formService.state.value as any).field, ['additionInfo'], 'Current page must be AdditionInfo page');
        done();
      }, 10);
    }, 100);
  })

  it('Should go to Job Screen if user enter full information', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    const childFormService: Actor<any, AnyEventObject> = formService.state.children['otp-machine'];
    setTimeout(function () {
      childFormService.send(CONFIRM_EVENT);
      childFormService.send('CONTINUE', {values: {otpConfirm: {state: {}, values: {otp: '1234'}}}});
      setTimeout(function() {
        childFormService.send('SUCCESS');
        formService.send("CONTINUE", {values: {profile: {state: {}, values: ["Đại học", "Kết hôn"]}}});
        formService.send("CONTINUE", {values: {address: {state: {}, values: ["Ho Chi Minh", "4", "12", "Doan Van Bo", "12"]}}});
        formService.send("CONTINUE", {values: {additionInfo: {state: {}, values: ["Cho thue", "12", "09102901290"]}}});
        assert.hasAllKeys((formService.state.value as any).field, ['job'], 'Current page must be Job page');
        done();
      }, 10);
    }, 100);
  })

  /* End Job Screen */

  /* WorkPlace Screen */
  it('Should not go to Workplace Screen if user not select job title', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    const childFormService: Actor<any, AnyEventObject> = formService.state.children['otp-machine'];
    setTimeout(function () {
      childFormService.send(CONFIRM_EVENT);
      childFormService.send('CONTINUE', {values: {otpConfirm: {state: {}, values: {otp: '1234'}}}});
      setTimeout(function() {
        childFormService.send('SUCCESS');
      formService.send("CONTINUE", {values: {profile: {state: {}, values: ["Đại học", "Kết hôn"]}}});
      formService.send("CONTINUE", {values: {address: {state: {}, values: ["Ho Chi Minh", "4", "12", "Doan Van Bo", "12"]}}});
      formService.send("CONTINUE", {values: {additionInfo: {state: {}, values: ["Cho thue", "12", "09102901290"]}}});
      formService.send("CONTINUE", {values: {job: {state: {}, values: []}}});
      assert.hasAllKeys((formService.state.value as any).field, ['job'], 'Current page must be Job page');
      done();
      }, 10);
    }, 100);
  })

  it('Should go to Workplace Screen if user enter full information', done => {
    const formService = interpret(ocbFormMachine).start();

    formService.send('LOGIN'); // Should go to field and initial with package field
    formService.send("CONTINUE", {values: {package: {state: {}, values: ["15", "12", ""]}}}); // Current page must be otp page when click next
    formService.send("CONTINUE", {values: {primaryInfo: {state: {}, values: {fullName: "name",email: "email@gmail.com",phoneNumber: "0963214937", loanPurpose: 'travel'}}}}); // Current page must be otp confirm page
    
    const childFormService: Actor<any, AnyEventObject> = formService.state.children['otp-machine'];
    setTimeout(function () {
      childFormService.send(CONFIRM_EVENT);
      childFormService.send('CONTINUE', {values: {otpConfirm: {state: {}, values: {otp: '1234'}}}});
      setTimeout(function() {
        childFormService.send('SUCCESS');
        formService.send("CONTINUE", {values: {profile: {state: {}, values: ["Đại học", "Kết hôn"]}}});
        formService.send("CONTINUE", {values: {address: {state: {}, values: ["Ho Chi Minh", "4", "12", "Doan Van Bo", "12"]}}});
        formService.send("CONTINUE", {values: {additionInfo: {state: {}, values: ["Cho thue", "12", "09102901290"]}}});
        formService.send("CONTINUE", {values: {job: {state: {}, values: ["Freelance"]}}});
        assert.hasAllKeys((formService.state.value as any).field, ['workplace'], 'Current page must be Workplace page');
        done();
      }, 10);
    }, 100);
  })

  /* End WorkPlace Screen */
})
