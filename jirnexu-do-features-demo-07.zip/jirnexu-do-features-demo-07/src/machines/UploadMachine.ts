import {Machine, assign} from 'xstate';
import { OCBContext } from "../forms/ocb";

const isTestMode = process.env.REACT_APP_MODE === 'test';

const uploadFile = async (context: OCBContext) => {
    if(isTestMode) {
        return new Promise(resolve => setTimeout(resolve, 10));
    }
    const data = new FormData();

    const { currentIndex, stacks, formValue } = context;
    const formValueKey = Object.keys(stacks[currentIndex - 1])[0];
    const values = formValue[formValueKey];
        
    const keys = Object.keys(values);
    keys.forEach((key: string) => {
        data.append('myFiles', values[key]);
    })
    
    return fetch('http://localhost:3001/uploadmultiple', {
        method: 'post',
        body: data
    }).then(response => response.json());
}

export const UploadMachine = Machine({
    id: 'upload-machine',
    initial: 'uploading',
    states: {
        uploading: {
            invoke: {
                id: 'uploading',
                src: (context: OCBContext) => uploadFile(context),
                onDone: {
                    actions: 'updateFormValue',
                    target: 'success'
                },
                onError: 'error'
            }
        },
        success: {
            type: 'final'
        },
        error: {
            
        }
    }
}, {
    actions: {
        updateFormValue: assign<OCBContext, any>({
            formValue: (context: OCBContext, event: any) => {
                const { currentIndex, stacks, formValue } = context;
                const formValueKey = Object.keys(stacks[currentIndex - 1])[0];
                const oldFiles = formValue[formValueKey];
                const newUploadedFiles = event.data;
                formValue[formValueKey] = Object.keys(oldFiles).reduce((prev: any, curr: any) => {
                    return {
                        ...prev,
                        [curr] : newUploadedFiles.filter((uploadFile: any) => uploadFile.originalname === oldFiles[curr]['name'])[0]
                    }
                }, {});
                return formValue;
            }
        })
    }
})