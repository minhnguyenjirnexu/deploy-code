import {UploadMachine} from './UploadMachine';
import { interpret } from 'xstate';
import { assert } from 'chai';

describe('Upload Machine', () => {
    it('should initial with uploading state', done => {
        const uploadMachine = interpret(UploadMachine).start();

        assert.equal(uploadMachine.initialState.value, 'uploading');
        done();
    })

    it('should invoke Upload File service when initial', done => {
      const uploadMachine = interpret(UploadMachine).start();
      assert.equal(uploadMachine.state.value, 'uploading', 'UploadMachine must be uploading state');
      assert.hasAllKeys(uploadMachine.children, ['uploading'],'UploadMachine must invoke service when initial uploading state');
      done();
    })

    it('should transition to success when upload successfully', done => {
        const uploadMachine = interpret(UploadMachine).start();
        setTimeout(() => {
            assert.equal(uploadMachine.state.value, 'success', 'UploadMachine must transition to success state after upload successfully');
            done();
        }, 100);
    })
})