import {IDOCRMachine} from './IDOCRMachine';
import { interpret } from 'xstate';
import { assert } from 'chai';

describe.only('ID OCR Machine', () => {
    it('should initial with uploading state', done => {
        const idOCRMachine = interpret(IDOCRMachine).start();

        assert.equal(idOCRMachine.initialState.value, 'uploading');
        done();
    })

    it('should invoke UploadMachine when initial', done => {
      const idOCRMachine = interpret(IDOCRMachine).start();
      assert.equal(idOCRMachine.state.value, 'uploading', 'IDOCRMachine must be uploading state');
      assert.hasAllKeys(idOCRMachine.children, ['uploading'],'IDOCRMachine must invoke UploadMachine when initial uploading state');
      done();
    })

    it('should transition to finish when upload successfully', done => {
        const idOCRMachine = interpret(IDOCRMachine).start();
        setTimeout(() => {
            assert.equal(idOCRMachine.state.value, 'finish', 'DLOCRMachine must transition to finish state after OCR successfully');
            done();
        }, 100);
    })
})