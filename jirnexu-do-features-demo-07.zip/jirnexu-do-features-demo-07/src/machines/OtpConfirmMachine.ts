import { Machine } from "xstate";
import { escalate } from "xstate/lib/actions";
const isTestMode = process.env.REACT_APP_MODE === 'test';
const checkOTP = (otp: String) => {
    if(isTestMode) {
        return new Promise((resolve, reject) =>  resolve({'isValidOtp': true}))
    }
    return fetch(`http://localhost:3001/otp/check/${otp}`).then(response => response.json());
}

export const OTPConfirmMachine = Machine({
    initial: 'waitingForCode',
    states: {
        waitingForCode: {
            on: {
                CODE: 'checkOTP'
            }
        },
        checkOTP: {
            invoke: {
                id: 'check-otp',
                src: (otp: String) => checkOTP(otp),
                onDone: [
                    {
                        target: 'success', 
                        cond: (context: any, event: any) => {
                            const {isValidOtp} = event.data;
                            return isValidOtp;
                        }
                    },
                    {
                        target: 'error'
                    }
                ],
                onError: 'error'
            }
        },
        success: {
            type: 'final'
        },
        error: {
            type: 'final',
            onEntry: escalate({isValidOtp: false})
        }
    }
})