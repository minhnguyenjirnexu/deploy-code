import { Machine } from "xstate";
import { escalate } from "xstate/lib/actions";
const isTestMode = process.env.REACT_APP_MODE === 'test';
const requestOTP = () => {
    if(isTestMode) {
        return new Promise(resolve =>  setTimeout(resolve, 10))
    }
    return fetch('http://localhost:3001/otp/request', {
        method: 'post'
    }).then(response => response.json());
}

export const OTPAskingMachine = Machine({
    initial: 'requesting',
    states: {
        requesting: {
            invoke: {
                id: 'request-otp',
                src: () => requestOTP(),
                onDone: 'success',
                onError: 'error'
            }
        },
        success: {
            type: 'final'
        },
        error: {
            type: 'final',
            onEntry: escalate('cannot get OTP')
        }
    }
})