import {OTPMachine} from './OtpMachine';
import { interpret } from 'xstate';
import { assert } from 'chai';

describe('OTP Machine', () => {
    it('should initial with idle state', done => {
        const otpMachine = interpret(OTPMachine).start();

        assert.equal(otpMachine.initialState.value, 'idle');
        done();
    })

    it('should go to ASKING state when send "CODE"', done => {
        const otpMachine = interpret(OTPMachine).start();
        otpMachine.send('CODE');
        assert.equal(otpMachine.state.value, 'asking', 'OTP should be transition to asking state');
        done();
    })

    it('should invoke the OTPAskingMachine when send "CODE"', done => {
        const otpMachine = interpret(OTPMachine).start();
        otpMachine.send('CODE');
        assert.equal(otpMachine.state.value, 'asking', 'OTP should be transition to asking state');
        assert.hasAllKeys(otpMachine.state.children, ['receive-otp'], 'OTP should invoke OTPAskingMachine as child');
        done();
    })

    it('should transition to otpConfirm State if server is resolve OTP back', done => {
        const otpMachine = interpret(OTPMachine).start();
        otpMachine.send('CODE');
        setTimeout(() => {
            assert.hasAllKeys(otpMachine.state.value, ['otpConfirm'], 'OTP must transition to confirm OTP state after get code');
            done();
        }, 100);
    })

    it('should transition to callOTP state after 100ms and 125s in real application', done => {
        const otpMachine = interpret(OTPMachine).start();
        otpMachine.send('CODE');
        setTimeout(() => {
            setTimeout(() => {
                assert.hasAllKeys(otpMachine.state.value, ['callOTP'], 'OTP must transition to call OTP state after 100 ms and 125s in real application');
                done();
            }, 100);
        }, 100);
    })

    it('should transition to timeout state after 1000ms in TEST MODE', done => {
        const otpMachine = interpret(OTPMachine).start();
        otpMachine.send('CODE');
        setTimeout(() => {
            assert.equal(otpMachine.state.value, 'timeout', 'OTP must transition to timeout state if user doesn\'t input anything in OTP state');
            done();
        }, 1000);
    })

    it('should transition to request state when send "RETRY" on timeout state in TEST MODE', done => {
        const otpMachine = interpret(OTPMachine).start();
        otpMachine.send('CODE');
        setTimeout(() => {
            otpMachine.send('RETRY');
            assert.equal(otpMachine.state.value, 'asking', 'OTP must transition to asking state when user retry');
            done();
        }, 1000);
    })

    it('should resend new otp code when send "RESEND" in call OTP state', done => {
        const otpMachine = interpret(OTPMachine).start();
        otpMachine.send('CODE');
        setTimeout(() => {
            otpMachine.send('RESEND');
            assert.equal(otpMachine.state.value, 'resending', 'OTP must trasition to resending state when user ask for resend code');
            done();
        }, 200);
    })
})
