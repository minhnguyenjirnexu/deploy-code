import { Machine } from "xstate";
import { OCBContext } from "../forms/ocb";
import { escalate, log } from "xstate/lib/actions";
import { UploadMachine } from "./UploadMachine";

const isTestMode = process.env.REACT_APP_MODE === 'test';

const idOCR = (context: OCBContext) => {
    if(isTestMode) {
        return new Promise(resolve => setTimeout(resolve, 10));
    }

    const idCard = context.formValue['idCard'];

    const headers = new Headers();
    // headers.append() : Add some header to send to PCO
    return fetch('https://localhost:3001/id/ocr', {
        method: 'post',
        body: JSON.stringify({
            idCard
        }),
        headers: headers
    }).then(response => response.json());
}

export const IDOCRMachine = Machine({
    id: 'id-ocr',
    initial: 'uploading',
    states: {
        uploading: {
            invoke: {
                id: 'uploading',
                src: UploadMachine,
                data: (context: any) => context,
                onDone: 'requesting'
            }
        },
        requesting: {
            entry: log('on requesting'),
            invoke: {
                id: 'invoke-ocr',
                src: (context: OCBContext) => idOCR(context),
                onDone: 'finish',
                onError: {
                    actions: escalate('Cannot get ID')
                }
            }
        },
        finish: {
            type: 'final'
        }
    }
})