import { Machine } from "xstate";
import { escalate } from "xstate/lib/actions";
const isTestMode = process.env.REACT_APP_MODE === 'test';
const resendOTP = () => {
    if(isTestMode) {
        return new Promise(resolve =>  setTimeout(resolve, 10))
    }
    return fetch('http://localhost:3001/otp/resend', {
        method: 'post'
    }).then(response => response.json());
}

export const OTPResendMachine = Machine({
    initial: 'resending',
    states: {
        resending: {
            invoke: {
                id: 'resend-otp',
                src: () => resendOTP(),
                onDone: 'success',
                onError: 'error'
            }
        },
        success: {
            type: 'final'
        },
        error: {
            type: 'final',
            onEntry: escalate('cannot get OTP')
        }
    }
})