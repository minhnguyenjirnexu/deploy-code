import { Machine } from "xstate";
import { OCBContext } from "../forms/ocb";
import { escalate } from "xstate/lib/actions";
import { UploadMachine } from "./UploadMachine";

const isTestMode = process.env.REACT_APP_MODE === 'test';

const dlOCR = (context: OCBContext) => {
    if(isTestMode) {
        return new Promise(resolve => setTimeout(resolve, 10));
    }
    const url = context.formValue['driverLicense'];
    const headers = new Headers();
    // headers.append() : Add some header to send to PCO
    return fetch('https://localhost:3001/dl/ocr', {
        method: 'post',
        body: JSON.stringify({
            url: url
        }),
        headers: headers
    }).then(response => response.json());
}

export const DLOCRMachine = Machine({
    id: 'id-ocr',
    initial: 'uploading',
    states: {
        uploading: {
            invoke: {
                id: 'uploading',
                src: UploadMachine,
                data: (context: any) => context,
                onDone: 'requesting'
            }
        },
        requesting: {
            invoke: {
                id: 'invoke-ocr',
                src: (context: OCBContext) => dlOCR(context),
                onDone: 'finish',
                onError: {
                    actions: escalate('Cannot get information from DL')
                }
            }
        },
        finish: {
            type: 'final'
        }
    }
})