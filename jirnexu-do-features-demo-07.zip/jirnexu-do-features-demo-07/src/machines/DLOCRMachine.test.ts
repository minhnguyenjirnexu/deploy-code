import {DLOCRMachine} from './DLOCRMachine';
import { interpret } from 'xstate';
import { assert } from 'chai';

describe('Driver License OCR Machine', () => {
    it('should initial with uploading state', done => {
        const dlOCRMachine = interpret(DLOCRMachine).start();

        assert.equal(dlOCRMachine.initialState.value, 'uploading');
        done();
    })

    it('should invoke UploadMachine when initial', done => {
      const dlOCRMachine = interpret(DLOCRMachine).start();
      assert.equal(dlOCRMachine.state.value, 'uploading', 'DLOCRMachine must be uploading state');
      assert.hasAllKeys(dlOCRMachine.children, ['uploading'],'DLOCRMachine must invoke UploadMachine when initial uploading state');
      done();
    })

    it('should transition to finish when upload successfully', done => {
        const dlOCRMachine = interpret(DLOCRMachine).start();
        setTimeout(() => {
            assert.equal(dlOCRMachine.state.value, 'finish', 'DLOCRMachine must transition to finish state after OCR successfully');
            done();
        }, 100);
    })
})