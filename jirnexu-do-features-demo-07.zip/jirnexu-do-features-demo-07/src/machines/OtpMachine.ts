import { Machine } from "xstate";
import { OTPAskingMachine } from "./OTPAskingMachine";
import { OTPConfirmMachine } from './OtpConfirmMachine';
import { send, assign, escalate } from "xstate/lib/actions";
import { OTPResendMachine } from "./OTPResendMachine";
import { OCBContext } from "../forms/ocb";

const CONFIRM_DELAY_TIME = process.env.REACT_APP_MODE !== 'test' ? 125000 : 100;
const TTS_DELAY_TIME = process.env.REACT_APP_MODE !== 'test' ? 185000 : 100;
// const FINAL_TTS_DELAY_TIME = 300000;

const otpConfirm = {
    after: {
      [CONFIRM_DELAY_TIME]: 'callOTP'
    },
    on: {
      CONTINUE: {
        target: 'confirming',
        actions: assign<any, any>({
          otp: (context: OCBContext, event: any) => {
            const {values} = event;
            return values['otpConfirm']['values']['otp'];
          }
        })
      },
    },
    meta: {
      title: 'Xác thực mã OTP',
      name: 'otpConfirm',
      subTitle: 'Mã xác thực OTP đã được gửi đến số điện thoại của bạn. Vui lòng nhập mã trong vòng 2 phút'
    },
    initial: 'otp',
    states: {
      otp: {
        meta: {
          title: '',
          placeholder: '****',
          validate: {
            minLength: 4,
            maxLength: 4
          },
          autocomplete: 'one-time-code'
        },
      }
    },
  }
  
const callOTP = {
  after: {
      [TTS_DELAY_TIME]: 'timeout'
  },
  on: {
    CONTINUE: {
      target: 'confirming',
      actions: 'updateStacks'
    },
    RESEND: 'resending',
  },
  meta: {
    title: 'Xác thực mã OTP',
    name: 'otpConfirm',
    subTitle: 'Mã xác thực OTP đã được gửi thông qua cuộc gọi từ tổng đài. Vui lòng nhập mã trong vòng 3 phút',
    hint: [
      {
        label: 'Không nhận được OTP?'
      },
      {
        label: 'Gửi lại',
        action: 'RESEND'
      }
    ]
  },
  initial: 'otp',
  states: {
    otp: {
      meta: {
        title: '',
        placeholder: '****',
        validate: {
          minLength: 4,
          maxLength: 4
        },
        autocomplete: 'one-time-code'
      },
      
    }
  }
}

export const OTPMachine = Machine({
    id: 'otp-machine',
    initial: 'idle',
    states: {
        idle: {
            on: {
                CODE: 'asking'
            }
        },
        asking: {
            invoke: {
                id: 'receive-otp',
                src: OTPAskingMachine,
                onDone: 'otpConfirm',
                onError: 'resending'
            }
        },
        resending: {
          invoke: {
              id: 'resend-otp',
              src: OTPResendMachine,
              onDone: 'otpConfirm',
              onError: 'resending'
          }
        },
        confirming: {
            invoke: {
                id: 'confirm-otp',
                src: OTPConfirmMachine,
                data: (context: any) => process.env.REACT_APP_MODE !== 'test' ? context.otp : '0000',
                onDone: 'success',
                onError: 'otpConfirm'
            }, 
            entry: send('CODE', {to: 'confirm-otp'})
        },
        otpConfirm: otpConfirm,
        callOTP: callOTP,
        success: {
            type: 'final'
        },
        error: {

      },
      timeout: {
        on: {
          RETRY: 'asking',
          EXIT: {
            actions: escalate('ERROR', {delay: 1})
          }
        }
      }
    },
})